<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rental Details</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/7a4aae7e35.js" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/7a4aae7e35.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
</head>

<body>


    <!-- header start -->
    <div id="profile_header">
        <div class="iconprofileheader">
            <i class="fa-solid fa-arrow-left-long fa-2x"></i>
        </div>
        <div id="profile_heading">
            <div id="profheadrev">Rental Details</div>
        </div>
        <div class="iconprofileheader">
            <i class="fa-solid fa-circle-chevron-down fa-2x"></i>
        </div>
    </div>
    <!-- header end -->

    <!-- request sent start -->
    <div id="request_start_rental">
        <div class="date_rental">
            05 JUL - 07 JUL 2022
        </div>
        <div id="req_btn">
            <div class="bigfont">Request Sent</div>
        </div>
    </div>
    <!-- request sent end -->

    <!-- profile start -->
    <div id="profile_rental">
        <div id="imgprogrental"></div>
        <div id="contentprogrental">
            <div class="low1 low2">Loewe</div>
            <div class="low1">Dress, UK 6</div>
        </div>
    </div>
    <!--  profile end-->

    <!-- calender start -->
    <div id="calrental">
        <div class="disflex"><i class="fa-solid fa-calendar-days fa-2x"></i></div>
        <div class="disflex1">
            <div class="date_rental">05 JUL - 07 JUL 2022</div>
        </div>
    </div>
    <!-- calender end -->

    <!-- price start -->
    <div class="del1">PRICE DETAILS</div>
    <div class="subdel2">
        <div class="subdel11">
            <div class="subdel21 bigfont">$13 x 3 days</div>
            <div class="subdel111 subdel21 bigfont">$39.00</div>
        </div>
        <div>
            <div class="subdel11">
                <div class="subdel21 bigfont">Service Fee (21%)</div>
                <div class="subdel111 subdel21 bigfont">$8.91</div>
            </div>
        </div>
        <div>
            <div class="subdel11">
                <div class="bigfont">Total</div>
                <div class="subdel111 bigfont">$47.91</div>
            </div>
        </div>

    </div>
    <!-- price detail end -->

    <!-- About rental start-->
    <div class="del1" style="margin-top: 20px;">ABOUT RENTER</div>
    <!-- profile start -->
    <div id="rendetprof">
        <div id="renderprof1">
            <div class="renderprof2">
                <div id="teea1pic"></div>
            </div>

            <div>
                <div class="bigfont">_niki_</div>
                <div><i class="fa-solid fa-star favcol"></i><i class="fa-solid fa-star favcol"></i><i class="fa-solid fa-star favcol"></i><i class="fa-solid fa-star favcol"></i><i class="fa-solid fa-star favcol"></i></div>
            </div>
        </div>
        <div class="renderprof2">
            <div id="messrent">
                <div class="bigfont">Message</div>
            </div>
        </div>
    </div>
    <!-- profile end -->
    <!-- about rental end -->

    <!-- first message start -->
    <div class="del1" style="margin-top: 40px;">THE FIRST MESSAGE FROM YOUR RENTER</div>
    <div class="bigfont" style="margin-top: 10px;color: rgb(164, 140, 140); padding-left: 15px;padding-right: 15px;">
        Hey, I would love to rent this for a wedding I'm attending. I'll be returning via Royal Mail.
    </div>
    <!-- first message end -->

    <!-- delivery INFO START -->
    <div class="del1" style="margin-top: 40px;">DELIVERY INFO</div>
    <div id="btndelinfo">
        <div id="reject" class="bigfont">
            <div>Reject</div>
        </div>
        <div id="accept" class="bigfont">
            <div>Accept</div>
        </div>
    </div>
    <!-- Delivery INFO END -->

    <!-- footer start -->
    <?php include 'footer.php' ?>
    <!-- footer end -->




    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>


</body>

</html>
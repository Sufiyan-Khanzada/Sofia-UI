<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="icon" type="image/png" href="images/icons/favicon.png" />
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/linearicons-v1.0.0/icon-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/slick/slick.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/MagnificPopup/magnific-popup.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/perfect-scrollbar/perfect-scrollbar.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css" />
    <!--===============================================================================================-->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/7a4aae7e35.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <link rel="stylesheet" type="text/css" href="css/nav.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <!-- Demo styles -->
    <style>
        body {
            font-family: Helvetica Neue, Helvetica, Arial, sans-serif;
            font-size: 14px;
            margin: 0;
            padding: 0;
        }
        
        .swiper {
            width: 100%;
            /* height: 50%; */
        }
        
        .swiper-slide {
            text-align: center;
            font-size: 18px;
            /* Center slide text vertically */
            display: -webkit-box;
            display: -ms-flexbox;
            display: -webkit-flex;
            display: flex;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            -webkit-justify-content: center;
            justify-content: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            -webkit-align-items: center;
            align-items: center;
        }
        
        .swiper-slide img {
            display: block;
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
    </style>
</head>

<body class="animsition">


    <!-- Header -->
    <header>
        <!-- Header desktop -->
        <div class="container-menu-desktop">
            <!-- Topbar -->
            <div class="top-bar">
                <div class="content-topbar flex-sb-m h-full container">
                    <div class="left-top-bar">
                        Free shipping for standard order over $100
                    </div>

                    <div class="right-top-bar flex-w h-full">
                        <a href="#" class="flex-c-m trans-04 p-lr-25">
                                                                        Help & FAQs
                                                              </a>

                        <a href="#" class="flex-c-m trans-04 p-lr-25">
                                                                        My Account
                                                              </a>

                        <a href="#" class="flex-c-m trans-04 p-lr-25">
                                                                        EN
                                                              </a>

                        <a href="#" class="flex-c-m trans-04 p-lr-25">
                                                                        USD
                                                              </a>
                    </div>
                </div>
            </div>

            <div class="wrap-menu-desktop">
                <nav class="limiter-menu-desktop container">

                    <!-- Logo desktop -->
                    <a href="#" class="logo">
                        <img src="images/icons/logo-01.png" alt="IMG-LOGO">
                    </a>

                    <!-- Menu desktop -->
                    <div class="menu-desktop">
                        <ul class="main-menu">
                            <li class="active-menu">
                                <a href="index.php">Home</a>
                                <ul class="sub-menu">
                                    <li><a href="index.php">Homepage 1</a></li>
                                    <li><a href="home-02.php">Homepage 2</a></li>
                                    <li><a href="home-03.php">Homepage 3</a></li>
                                </ul>
                            </li>

                            <li>
                                <a href="product.php">Shop</a>
                            </li>

                            <li class="label1" data-label1="hot">
                                <a href="shoping-cart.php">Features</a>
                            </li>

                            <li>
                                <a href="blog.php">Blog</a>
                            </li>

                            <li>
                                <a href="about.php">About</a>
                            </li>

                            <li>
                                <a href="contact.php">Contact</a>
                            </li>
                        </ul>
                    </div>

                    <!-- Icon header -->
                    <div class="wrap-icon-header flex-w flex-r-m">
                        <div class="icon-header-item cl2 hov-cl1 trans-04 p-l-22 p-r-11 js-show-modal-search">
                            <i class="zmdi zmdi-search"></i>
                        </div>

                        <div class="icon-header-item cl2 hov-cl1 trans-04 p-l-22 p-r-11 icon-header-noti js-show-cart" data-notify="2">
                            <i class="zmdi zmdi-shopping-cart"></i>
                        </div>

                        <a href="#" class="dis-block icon-header-item cl2 hov-cl1 trans-04 p-l-22 p-r-11 icon-header-noti" data-notify="0">
                            <i class="zmdi zmdi-favorite-outline"></i>
                        </a>
                    </div>
                </nav>
            </div>
        </div>

        <!-- Header Mobile -->
        <div class="wrap-header-mobile">
            <!-- Logo moblie -->
            <div class="logo-mobile">
                <a href="index.php"><img src="images/icons/logo-01.png" alt="IMG-LOGO"></a>
            </div>

            <!-- Icon header -->
            <div class="wrap-icon-header flex-w flex-r-m m-r-15">
                <div class="icon-header-item cl2 hov-cl1 trans-04 p-r-11 js-show-modal-search">
                    <i class="zmdi zmdi-search"></i>
                </div>

                <div class="icon-header-item cl2 hov-cl1 trans-04 p-r-11 p-l-10 icon-header-noti js-show-cart" data-notify="2">
                    <i class="zmdi zmdi-shopping-cart"></i>
                </div>

                <a href="#" class="dis-block icon-header-item cl2 hov-cl1 trans-04 p-r-11 p-l-10 icon-header-noti" data-notify="0">
                    <i class="zmdi zmdi-favorite-outline"></i>
                </a>
            </div>

            <!-- Button show menu -->
            <div class="btn-show-menu-mobile hamburger hamburger--squeeze">
                <span class="hamburger-box">
                                                    <span class="hamburger-inner"></span>
                </span>
            </div>
        </div>


        <!-- Menu Mobile -->
        <div class="menu-mobile">
            <ul class="topbar-mobile">
                <li>
                    <div class="left-top-bar">
                        Free shipping for standard order over $100
                    </div>
                </li>

                <li>
                    <div class="right-top-bar flex-w h-full">
                        <a href="#" class="flex-c-m p-lr-10 trans-04">
                                                                        Help & FAQs
                                                              </a>

                        <a href="#" class="flex-c-m p-lr-10 trans-04">
                                                                        My Account
                                                              </a>

                        <a href="#" class="flex-c-m p-lr-10 trans-04">
                                                                        EN
                                                              </a>

                        <a href="#" class="flex-c-m p-lr-10 trans-04">
                                                                        USD
                                                              </a>
                    </div>
                </li>
            </ul>

            <ul class="main-menu-m">
                <li>
                    <a href="index.php">Home</a>
                    <ul class="sub-menu-m">
                        <li><a href="index.php">Homepage 1</a></li>
                        <li><a href="home-02.php">Homepage 2</a></li>
                        <li><a href="home-03.php">Homepage 3</a></li>
                    </ul>
                    <span class="arrow-main-menu-m">
                                                              <i class="fa fa-angle-right" aria-hidden="true"></i>
                                                    </span>
                </li>

                <li>
                    <a href="product.php">Shop</a>
                </li>

                <li>
                    <a href="shoping-cart.php" class="label1 rs1" data-label1="hot">Features</a>
                </li>

                <li>
                    <a href="blog.php">Blog</a>
                </li>

                <li>
                    <a href="about.php">About</a>
                </li>

                <li>
                    <a href="contact.php">Contact</a>
                </li>
            </ul>
        </div>

        <!-- Modal Search -->
        <div class="modal-search-header flex-c-m trans-04 js-hide-modal-search">
            <div class="container-search-header">
                <button class="flex-c-m btn-hide-modal-search trans-04 js-hide-modal-search">
                                                    <img src="images/icons/icon-close2.png" alt="CLOSE">
                                          </button>

                <form class="wrap-search-header flex-w p-l-15">
                    <button class="flex-c-m trans-04">
                                                              <i class="zmdi zmdi-search"></i>
                                                    </button>
                    <input class="plh3" type="text" name="search" placeholder="Search...">
                </form>
            </div>
        </div>
    </header>
    <!-- header end -->


    <!-- carousel header start -->
    <div class="swiper mySwiper heightswip">
        <div class="swiper-wrapper">
            <div class="swiper-slide ">
                <div class="carouselindex ">
                    <div class="txtcarind ">

                        <div class="mainheadtxtind">

                            Men Collection 2018

                        </div>

                        <div class="mainheadtxtind1">New Arrivals</div>
                        <div>
                            <!-- HTML !-->
                            <button class="button-36" role="button">Shop Now</button>

                        </div>

                    </div>
                    <div id="carouselimgind1">
                        <!-- <img src="carousel3.png" /> -->
                    </div>

                </div>
            </div>
            <!-- <div class="swiper-slide">
                <div class="carouselindex">
                    <div class="txtcarind">
                        <div class="mainheadtxtind">

                            Women Collection 2018

                        </div>

                        <div class="mainheadtxtind1">New Arrivals</div>
                        <div><button class="button-36" role="button">Shop Now</button></div>
                    </div>
                    <div id="carouselimgind2"></div>

                </div>
            </div>
            <div class="swiper-slide">
                <div class="carouselindex">
                    <div class="txtcarind">
                        <div class="mainheadtxtind">

                            Watch Collection 2018

                        </div>

                        <div class="mainheadtxtind1">New Arrivals</div>
                        <div><button class="button-36" role="button">Shop Now</button></div>
                    </div>
                    <div id="carouselimgind3">

                    </div>

                </div>
            </div> -->

            <!-- <div class="swiper-slide"> 
            <div class="carouselindex">
                <div></div>
                <div class="carouselimgind"></div>

            </div>
        </div> -->
            <!-- <div class="swiper-slide">Slide 6</div>
            <div class="swiper-slide">Slide 7</div>
            <div class="swiper-slide">Slide 8</div>
            <div class="swiper-slide">Slide 9</div> -->
        </div>
        <!-- <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div> -->
        <div class="swiper-pagination"></div>
    </div>



    <!-- carousel header end -->

    <!-- Recommended start -->
    <div class="recind">
        <span class="recindtxt">Recommended For You</span>

    </div>
    <!-- recommended end -->

    <!-- recommended carousel start -->



    <!-- recommended carousel end -->
    <div class="swiper mySwiper1 marswip ht6">
        <div class="swiper-wrapper htswip1 bgnone">
            <div class="swiper-slide htwidth">
                <div class="discardind shadow p-3 mb-5 bg-white rounded">
                    <div>
                        <a href="product-detail.php"><img src="images/product-06.jpg" alt="IMG-PRODUCT"></a>


                    </div>
                    <div class="txt-content-swip">
                        <div class="txt-content-swip1">
                            <div>
                                <div class="txt-content-swip2 txt-content-swip3">Herschel supply</div>
                            </div>
                            <div><i class="fa-regular fa-heart"></i></div>
                        </div>
                        <div class="txt-content-swip3">
                            <div class="head1txt">Brand: </div> <span class="txtsubcard">Tory Burch</span>

                        </div>
                        <div class="txt-content-swip4">
                            <button class="button-18" role="button"><span class="txtsubcard1">€36.52 / Day</span></button>

                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide htwidth">
                <div class="discardind shadow-lg p-3 mb-5 bg-white rounded">
                    <div class="">
                        <a href="product-detail.php"><img src="images/product-06.jpg" alt="IMG-PRODUCT"></a>


                    </div>
                    <div class="txt-content-swip">
                        <div class="txt-content-swip1">
                            <div>
                                <div class="txt-content-swip2 txt-content-swip3">Herschel supply</div>
                            </div>
                            <div><i class="fa-regular fa-heart"></i></div>
                        </div>
                        <div class="txt-content-swip3">
                            <div class="head1txt">Brand: </div> <span class="txtsubcard">Tory Burch</span>

                        </div>
                        <div class="txt-content-swip4">
                            <button class="button-18" role="button"><span class="txtsubcard1">€36.52 / Day</span></button>

                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide htwidth">
                <div class="discardind shadow p-3 mb-5 bg-white rounded">
                    <div class="">
                        <a href="product-detail.php"><img src="images/product-06.jpg" alt="IMG-PRODUCT"></a>


                    </div>
                    <div class="txt-content-swip">
                        <div class="txt-content-swip1">
                            <div>
                                <div class="txt-content-swip2 txt-content-swip3">Herschel supply</div>
                            </div>
                            <div><i class="fa-regular fa-heart"></i></div>
                        </div>
                        <div class="txt-content-swip3">
                            <div class="head1txt">Brand: </div> <span class="txtsubcard">Tory Burch</span>

                        </div>
                        <div class="txt-content-swip4">
                            <button class="button-18" role="button"><span class="txtsubcard1">€36.52 / Day</span></button>

                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide htwidth">
                <div class="discardind shadow p-3 mb-5 bg-white rounded">
                    <div class="">
                        <a href="product-detail.php"><img src="images/product-06.jpg" alt="IMG-PRODUCT"></a>


                    </div>
                    <div class="txt-content-swip">
                        <div class="txt-content-swip1">
                            <div>
                                <div class="txt-content-swip2 txt-content-swip3">Herschel supply</div>
                            </div>
                            <div><i class="fa-regular fa-heart"></i></div>
                        </div>
                        <div class="txt-content-swip3">
                            <div class="head1txt">Brand: </div> <span class="txtsubcard">Tory Burch</span>

                        </div>
                        <div class="txt-content-swip4">
                            <button class="button-18" role="button"><span class="txtsubcard1">€36.52 / Day</span></button>

                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide htwidth">
                <div class="discardind shadow p-3 mb-5 bg-white rounded">
                    <div class="">
                        <a href="product-detail.php"><img src="images/product-06.jpg" alt="IMG-PRODUCT"></a>


                    </div>
                    <div class="txt-content-swip">
                        <div class="txt-content-swip1">
                            <div>

                                <div class="txt-content-swip2 txt-content-swip3">Herschel supply</div>
                            </div>
                            <div><i class="fa-regular fa-heart"></i></div>
                        </div>
                        <div class="txt-content-swip3">
                            <div class="head1txt">Brand: </div> <span class="txtsubcard">Tory Burch</span>

                        </div>
                        <div class="txt-content-swip4">
                            <button class="button-18" role="button"><span class="txtsubcard1">€36.52 / Day</span></button>

                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide htwidth">
                <div class="discardind shadow p-3 mb-5 bg-white rounded">
                    <div class="">
                        <a href="product-detail.php"><img src="images/product-06.jpg" alt="IMG-PRODUCT"></a>


                    </div>
                    <div class="txt-content-swip">
                        <div class="txt-content-swip1">
                            <div>
                                <div class="txt-content-swip2 txt-content-swip3">Herschel supply</div>
                            </div>
                            <div><i class="fa-regular fa-heart"></i></div>
                        </div>
                        <div class="txt-content-swip3">
                            <div class="head1txt">Brand: </div> <span class="txtsubcard">Tory Burch</span>

                        </div>
                        <div class="txt-content-swip4">
                            <button class="button-18" role="button"><span class="txtsubcard1">€36.52 / Day</span></button>

                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide htwidth">
                <div class="discardind shadow p-3 mb-5 bg-white rounded">
                    <div class="">
                        <a href="product-detail.php"><img src="images/product-06.jpg" alt="IMG-PRODUCT"></a>


                    </div>
                    <div class="txt-content-swip">
                        <div class="txt-content-swip1">
                            <div>
                                <div class="txt-content-swip2 txt-content-swip3">Herschel supply</div>
                            </div>
                            <div><i class="fa-regular fa-heart"></i></div>
                        </div>
                        <div class="txt-content-swip3">
                            <div class="head1txt">Brand: </div> <span class="txtsubcard">Tory Burch</span>

                        </div>
                        <div class="txt-content-swip4">
                            <button class="button-18" role="button"><span class="txtsubcard1">€36.52 / Day</span></button>

                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide htwidth">
                <div class="discardind shadow p-3 mb-5 bg-white rounded">
                    <div class="">
                        <a href="product-detail.php"><img src="images/product-06.jpg" alt="IMG-PRODUCT"></a>


                    </div>
                    <div class="txt-content-swip">
                        <div class="txt-content-swip1">
                            <div>
                                <div class="txt-content-swip2 txt-content-swip3">Herschel supply</div>
                            </div>
                            <div><i class="fa-regular fa-heart"></i></div>
                        </div>
                        <div class="txt-content-swip3">
                            <div class="head1txt">Brand: </div> <span class="txtsubcard">Tory Burch</span>

                        </div>
                        <div class="txt-content-swip4">
                            <button class="button-18" role="button"><span class="txtsubcard1">€36.52 / Day</span></button>

                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide htwidth">
                <div class="discardind shadow p-3 mb-5 bg-white rounded">
                    <div class="">
                        <a href="product-detail.php"><img src="images/product-06.jpg" alt="IMG-PRODUCT"></a>


                    </div>
                    <div class="txt-content-swip">
                        <div class="txt-content-swip1">
                            <div>
                                <div class="txt-content-swip2 txt-content-swip3">Herschel supply</div>
                            </div>
                            <div><i class="fa-regular fa-heart"></i></div>
                        </div>
                        <div class="txt-content-swip3">
                            <div class="head1txt">Brand: </div> <span class="txtsubcard">Tory Burch</span>

                        </div>
                        <div class="txt-content-swip4">
                            <button class="button-18" role="button"><span class="txtsubcard1">€36.52 / Day</span></button>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="swiper-pagination"></div>
    </div>

    <!-- trending start -->
    <div class="recind">
        <span class="recindtxt">Trending</span>

    </div>
    <!-- trending end -->

    <!-- trending carousel start -->

    <div class="swiper mySwiper1 marswip">
        <div class="swiper-wrapper htswip1 ">
            <div class="swiper-slide htwidth">
                <div class="discardind shadow p-3 mb-5 bg-white rounded">
                    <div class="">
                        <a href="product-detail.php"><img src="images/product-06.jpg" alt="IMG-PRODUCT"></a>


                    </div>
                    <div class="txt-content-swip">
                        <div class="txt-content-swip1">
                            <div>
                                <div class="txt-content-swip2 txt-content-swip3">Herschel supply</div>
                            </div>
                            <div><i class="fa-regular fa-heart"></i></div>
                        </div>
                        <div class="txt-content-swip3">
                            <div class="head1txt">Brand: </div> <span class="txtsubcard">Tory Burch</span>

                        </div>
                        <div class="txt-content-swip4">
                            <button class="button-18" role="button"><span class="txtsubcard1">€36.52 / Day</span></button>

                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide htwidth">
                <div class="discardind shadow p-3 mb-5 bg-white rounded">
                    <div class="">
                        <a href="product-detail.php"><img src="images/product-06.jpg" alt="IMG-PRODUCT"></a>


                    </div>
                    <div class="txt-content-swip">
                        <div class="txt-content-swip1">
                            <div>
                                <div class="txt-content-swip2 txt-content-swip3">Herschel supply</div>
                            </div>
                            <div><i class="fa-regular fa-heart"></i></div>
                        </div>
                        <div class="txt-content-swip3">
                            <div class="head1txt">Brand: </div> <span class="txtsubcard">Tory Burch</span>

                        </div>
                        <div class="txt-content-swip4">
                            <button class="button-18" role="button"><span class="txtsubcard1">€36.52 / Day</span></button>

                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide htwidth">
                <div class="discardind shadow p-3 mb-5 bg-white rounded">
                    <div class="">
                        <a href="product-detail.php"><img src="images/product-06.jpg" alt="IMG-PRODUCT"></a>


                    </div>
                    <div class="txt-content-swip">
                        <div class="txt-content-swip1">
                            <div>
                                <div class="txt-content-swip2 txt-content-swip3">Herschel supply</div>
                            </div>
                            <div><i class="fa-regular fa-heart"></i></div>
                        </div>
                        <div class="txt-content-swip3">
                            <div class="head1txt">Brand: </div> <span class="txtsubcard">Tory Burch</span>

                        </div>
                        <div class="txt-content-swip4">
                            <button class="button-18" role="button"><span class="txtsubcard1">€36.52 / Day</span></button>

                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide htwidth">
                <div class="discardind shadow p-3 mb-5 bg-white rounded">
                    <div class="">
                        <a href="product-detail.php"><img src="images/product-06.jpg" alt="IMG-PRODUCT"></a>


                    </div>
                    <div class="txt-content-swip">
                        <div class="txt-content-swip1">
                            <div>
                                <div class="txt-content-swip2 txt-content-swip3">Herschel supply</div>
                            </div>
                            <div><i class="fa-regular fa-heart"></i></div>
                        </div>
                        <div class="txt-content-swip3">
                            <div class="head1txt">Brand: </div> <span class="txtsubcard">Tory Burch</span>

                        </div>
                        <div class="txt-content-swip4">
                            <button class="button-18" role="button"><span class="txtsubcard1">€36.52 / Day</span></button>

                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide htwidth">
                <div class="discardind shadow p-3 mb-5 bg-white rounded">
                    <div class="">
                        <a href="product-detail.php"><img src="images/product-06.jpg" alt="IMG-PRODUCT"></a>


                    </div>
                    <div class="txt-content-swip">
                        <div class="txt-content-swip1">
                            <div>
                                <div class="txt-content-swip2 txt-content-swip3">Herschel supply</div>
                            </div>
                            <div><i class="fa-regular fa-heart"></i></div>
                        </div>
                        <div class="txt-content-swip3">
                            <div class="head1txt">Brand: </div> <span class="txtsubcard">Tory Burch</span>

                        </div>
                        <div class="txt-content-swip4">
                            <button class="button-18" role="button"><span class="txtsubcard1">€36.52 / Day</span></button>

                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide htwidth">
                <div class="discardind shadow p-3 mb-5 bg-white rounded">
                    <div class="">
                        <a href="product-detail.php"><img src="images/product-06.jpg" alt="IMG-PRODUCT"></a>


                    </div>
                    <div class="txt-content-swip">
                        <div class="txt-content-swip1">
                            <div>
                                <div class="txt-content-swip2 txt-content-swip3">Herschel supply</div>
                            </div>
                            <div><i class="fa-regular fa-heart"></i></div>
                        </div>
                        <div class="txt-content-swip3">
                            <div class="head1txt">Brand: </div> <span class="txtsubcard">Tory Burch</span>

                        </div>
                        <div class="txt-content-swip4">
                            <button class="button-18" role="button"><span class="txtsubcard1">€36.52 / Day</span></button>

                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide htwidth">
                <div class="discardind shadow p-3 mb-5 bg-white rounded">
                    <div class="">
                        <a href="product-detail.php"><img src="images/product-06.jpg" alt="IMG-PRODUCT"></a>


                    </div>
                    <div class="txt-content-swip">
                        <div class="txt-content-swip1">
                            <div>
                                <div class="txt-content-swip2 txt-content-swip3">Herschel supply</div>
                            </div>
                            <div><i class="fa-regular fa-heart"></i></div>
                        </div>
                        <div class="txt-content-swip3">
                            <div class="head1txt">Brand: </div> <span class="txtsubcard">Tory Burch</span>

                        </div>
                        <div class="txt-content-swip4">
                            <button class="button-18" role="button"><span class="txtsubcard1">€36.52 / Day</span></button>

                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide htwidth">
                <div class="discardind shadow p-3 mb-5 bg-white rounded">
                    <div class="">
                        <a href="product-detail.php"><img src="images/product-06.jpg" alt="IMG-PRODUCT"></a>


                    </div>
                    <div class="txt-content-swip">
                        <div class="txt-content-swip1">
                            <div>
                                <div class="txt-content-swip2 txt-content-swip3">Herschel supply</div>
                            </div>
                            <div><i class="fa-regular fa-heart"></i></div>
                        </div>
                        <div class="txt-content-swip3">
                            <div class="head1txt">Brand: </div> <span class="txtsubcard">Tory Burch</span>

                        </div>
                        <div class="txt-content-swip4">
                            <button class="button-18" role="button"><span class="txtsubcard1">€36.52 / Day</span></button>

                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide htwidth">
                <div class="discardind shadow p-3 mb-5 bg-white rounded">
                    <div class="">
                        <a href="product-detail.php"><img src="images/product-06.jpg" alt="IMG-PRODUCT"></a>


                    </div>
                    <div class="txt-content-swip">
                        <div class="txt-content-swip1">
                            <div>
                                <div class="txt-content-swip2 txt-content-swip3">Herschel supply</div>
                            </div>
                            <div><i class="fa-regular fa-heart"></i></div>
                        </div>
                        <div class="txt-content-swip3">
                            <div class="head1txt">Brand: </div> <span class="txtsubcard">Tory Burch</span>

                        </div>
                        <div class="txt-content-swip4">
                            <button class="button-18" role="button"><span class="txtsubcard1">€36.52 / Day</span></button>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="swiper-pagination"></div>
    </div>

    <!-- trending carousel end -->

    <!-- featured brand start -->
    <div class="recind">
        <span class="recindtxt">Featured Brands</span>

    </div>
    <!-- featured brand end -->

    <!-- featured brand carousel start -->

    <div class="swiper mySwiper1 marswip htlogo">
        <div class="swiper-wrapper  bgnone">
            <div class="swiper-slide bgnone">
                
                    <div>
                        <a href="product-detail.php"><img src="brandslogo.png" alt="IMG-PRODUCT"></a>


                    </div>
                    
            </div>
            <div class="swiper-slide">
                
                <div>
                        <a href="product-detail.php"><img src="brandslogo.png" alt="IMG-PRODUCT"></a>


                    </div>
                    
            </div>
            <div class="swiper-slide">
            <div>
                        <a href="product-detail.php"><img src="brandslogo.png" alt="IMG-PRODUCT"></a>


                    </div>
            </div>
            <div class="swiper-slide">
            <div>
                        <a href="product-detail.php"><img src="brandslogo.png" alt="IMG-PRODUCT"></a>


                    </div>
            </div>
            <div class="swiper-slide">
            <div>
                        <a href="product-detail.php"><img src="brandslogo.png" alt="IMG-PRODUCT"></a>


                    </div>
            </div>
            <div class="swiper-slide">
            <div>
                        <a href="product-detail.php"><img src="brandslogo.png" alt="IMG-PRODUCT"></a>


                    </div>
            </div>
            <div class="swiper-slide">
            <div>
                        <a href="product-detail.php"><img src="brandslogo.png" alt="IMG-PRODUCT"></a>


                    </div>
            </div>
            <div class="swiper-slide">
            <div>
                        <a href="product-detail.php"><img src="brandslogo.png" alt="IMG-PRODUCT"></a>


                    </div>
            </div>
            <div class="swiper-slide">
            <div>
                        <a href="product-detail.php"><img src="brandslogo.png" alt="IMG-PRODUCT"></a>


                    </div>
            </div>
        </div>
        <div class="swiper-pagination"></div>
    </div>

    <!-- featured brand carousel end -->

    <div class="gapfoot">

    </div>


    <!-- Footer -->
    <div class="main-footer">
    <footer class="bg3 p-t-75 p-b-32">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-lg-3 p-b-50">
                    <h4 class="stext-301 cl0 p-b-30">
                        Categories
                    </h4>

                    <ul>
                        <li class="p-b-10">
                            <a href="#" class="stext-107 cl7 hov-cl1 trans-04">
                                                                              Women
                                                                    </a>
                        </li>

                        <li class="p-b-10">
                            <a href="#" class="stext-107 cl7 hov-cl1 trans-04">
                                                                              Men
                                                                    </a>
                        </li>

                        <li class="p-b-10">
                            <a href="#" class="stext-107 cl7 hov-cl1 trans-04">
                                                                              Shoes
                                                                    </a>
                        </li>

                        <li class="p-b-10">
                            <a href="#" class="stext-107 cl7 hov-cl1 trans-04">
                                                                              Watches
                                                                    </a>
                        </li>
                    </ul>
                </div>

                <div class="col-sm-6 col-lg-3 p-b-50">
                    <h4 class="stext-301 cl0 p-b-30">
                        Help
                    </h4>

                    <ul>
                        <li class="p-b-10">
                            <a href="#" class="stext-107 cl7 hov-cl1 trans-04">
                                                                              Track Order
                                                                    </a>
                        </li>

                        <li class="p-b-10">
                            <a href="#" class="stext-107 cl7 hov-cl1 trans-04">
                                                                              Returns 
                                                                    </a>
                        </li>

                        <li class="p-b-10">
                            <a href="#" class="stext-107 cl7 hov-cl1 trans-04">
                                                                              Shipping
                                                                    </a>
                        </li>

                        <li class="p-b-10">
                            <a href="#" class="stext-107 cl7 hov-cl1 trans-04">
                                                                              FAQs
                                                                    </a>
                        </li>
                    </ul>
                </div>

                <div class="col-sm-6 col-lg-3 p-b-50">
                    <h4 class="stext-301 cl0 p-b-30">
                        GET IN TOUCH
                    </h4>

                    <p class="stext-107 cl7 size-201">
                        Any questions? Let us know in store at 8th floor, 379 Hudson St, New York, NY 10018 or call us on (+1) 96 716 6879
                    </p>

                    <div class="p-t-27">
                        <a href="#" class="fs-18 cl7 hov-cl1 trans-04 m-r-16">
                            <i class="fa fa-facebook"></i>
                        </a>

                        <a href="#" class="fs-18 cl7 hov-cl1 trans-04 m-r-16">
                            <i class="fa fa-instagram"></i>
                        </a>

                        <a href="#" class="fs-18 cl7 hov-cl1 trans-04 m-r-16">
                            <i class="fa fa-pinterest-p"></i>
                        </a>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-3 p-b-50">
                    <h4 class="stext-301 cl0 p-b-30">
                        Newsletter
                    </h4>

                    <form>
                        <div class="wrap-input1 w-full p-b-4">
                            <input class="input1 bg-none plh1 stext-107 cl7" type="text" name="email" placeholder="email@example.com">
                            <div class="focus-input1 trans-04"></div>
                        </div>

                        <div class="p-t-18">
                            <button class="flex-c-m stext-101 cl0 size-103 bg1 bor1 hov-btn2 p-lr-15 trans-04">
                                                                              Subscribe
                                                                    </button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="p-t-40">
                <div class="flex-c-m flex-w p-b-18">
                    <a href="#" class="m-all-1">
                        <img src="images/icons/icon-pay-01.png" alt="ICON-PAY">
                    </a>

                    <a href="#" class="m-all-1">
                        <img src="images/icons/icon-pay-02.png" alt="ICON-PAY">
                    </a>

                    <a href="#" class="m-all-1">
                        <img src="images/icons/icon-pay-03.png" alt="ICON-PAY">
                    </a>

                    <a href="#" class="m-all-1">
                        <img src="images/icons/icon-pay-04.png" alt="ICON-PAY">
                    </a>

                    <a href="#" class="m-all-1">
                        <img src="images/icons/icon-pay-05.png" alt="ICON-PAY">
                    </a>
                </div>

                <p class="stext-107 cl6 txt-center">
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    Copyright &copy;
                    <script>
                        document.write(new Date().getFullYear());
                    </script> All rights reserved | Made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a> &amp; distributed by <a href="https://themewagon.com" target="_blank">ThemeWagon</a>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->

                </p>
            </div>
        </div>
    </footer>
    <nav class="mobile-nav">
        <a href="#" class="bloc-icon">
            <img src="ressources/home.svg" alt="">
        </a>
        <a href="#" class="bloc-icon">
            <img src="ressources/heart.svg" alt="">
        </a>
        <a href="#" class="bloc-icon">
            <img src="ressources/magnifying-glass.svg" alt="">
        </a>
        <a href="#" class="bloc-icon">
            <img src="ressources/plus.svg" alt="">
        </a>
        <a href="#" class="bloc-icon">
            <img src="ressources/user.svg" alt="">
        </a>
    </nav>
    </div>

    <!-- Back to top -->
    <!-- <div class="btn-back-to-top" id="myBtn">
                  <span class="symbol-btn-back-to-top">
                            <i class="zmdi zmdi-chevron-up"></i>
                  </span>
        </div> -->

    <!-- Back to top -->
    <div class="btn-back-to-top" id="myBtn">
        <span class="symbol-btn-back-to-top">
                            <i class="zmdi zmdi-chevron-up"></i>
                  </span>
    </div>

    <!-- footer start -->
    <?php include 'footer.php' ?>
    <!-- footer end -->

    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>

    <!-- Initialize Swiper -->
    <script>
        function myFunction(x) {
            if (x.matches) {
                var swiper = new Swiper(".mySwiper1", {
                    slidesPerView: 2,
                    spaceBetween: 30,
                    autoplay: {
                        delay: 2500,
                        disableOnInteraction: false,
                    },
                    pagination: {
                        el: ".swiper-pagination",
                        clickable: true,
                    },
                });
            } else {
                var swiper = new Swiper(".mySwiper1", {
                    slidesPerView: 4,
                    spaceBetween: 30,
                    autoplay: {
                        delay: 2500,
                        disableOnInteraction: false,
                    },
                    pagination: {
                        el: ".swiper-pagination",
                        clickable: true,
                    },
                });
            }
        }

        var x = window.matchMedia("(max-width: 700px)")

        myFunction(x)
        x.addListener(myFunction)
    </script>
    <script>
        var swiper = new Swiper(".mySwiper", {
            cssMode: true,
            autoplay: {
                delay: 2500,
                disableOnInteraction: false,
            },
            navigation: {
                nextEl: ".swiper-button-next",
                prevEl: ".swiper-button-prev",
            },
            pagination: {
                el: ".swiper-pagination",
            },
            mousewheel: true,
            keyboard: true,
        });
    </script>

    <script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script>
        $('.js-pscroll').each(function() {
            $(this).css('position', 'relative');
            $(this).css('overflow', 'hidden');
            var ps = new PerfectScrollbar(this, {
                wheelSpeed: 1,
                scrollingThreshold: 1000,
                wheelPropagation: false,
            });

            $(window).on('resize', function() {
                ps.update();
            })
        });
    </script>

    <script src="vendor/jquery/jquery-3.2.1.min.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/animsition/js/animsition.min.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/bootstrap/js/popper.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>


    <script src="js/main.js"></script>
    <script>
        AOS.init();
    </script>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>






</body>

</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rental Activity</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/7a4aae7e35.js" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/7a4aae7e35.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
</head>

<body>


    <!-- header start -->
    <div id="profile_header">
        <div class="iconprofileheader">
            <i class="fa-solid fa-arrow-left-long fa-2x"></i>
        </div>
        <div id="profile_heading">
            <div id="profheadrev">Lender Activity</div>
        </div>
        <div class="iconprofileheader">
            <i class="fa-solid fa-circle-chevron-down fa-2x"></i>
        </div>
    </div>
    <!-- header end -->

    <!-- price start -->
    <div style="font-size:30px ;font-weight: bolder;margin-left: 15px;margin-bottom: 10px;">$2,555.29</div>
    <div style="font-size:15px ;font-weight: 10px;margin-left: 15px;margin-bottom: 10px;">Your Income</div>
    <!-- price end -->

    <!-- payouts start-->

    <div id="payoutlender">
        <div class="containerpayout">
            <div style="display: flex; justify-content: flex-start;align-items: center;">
                <div style="font-weight: bold">Payouts</div>
            </div>
            <div style="display: flex; justify-content: flex-end;align-items: center;">
                <div>$2,555.29</div>
            </div>
        </div>
        <div class="containerpayout">
            <div style="display: flex; justify-content: flex-start;align-items: center;">
                <div style="font-weight: bold">Future Payouts</div>
            </div>
            <div style="display: flex; justify-content: flex-end;align-items: center;">
                <div>$0.00</div>
            </div>
        </div>
    </div>

    <!-- payouts end -->

    <!-- update stripe start -->
    <div id="applybtn">
        <div id="discountbtn1">
            <div>Update Your Stripe</div>
        </div>
    </div>

    <!-- update stripe end -->

    <!-- bank account detail start -->

    <div id="payoutlender">
        <div class="containerpayout">
            <div style="display: flex; justify-content: flex-start;align-items: center;">
                <div style="font-weight: bold;font-size:20px">BANK ACCOUNT</div>
            </div>
            <div style="display: flex; justify-content: flex-end;align-items: center;">
                <div style="color: green;font-weight: bolder;">ADD</div>
            </div>
        </div>
        <div class="containerpayout">
            <div>
                <div style="font-weight: bold">.......675</div>
                <div>BARCLAYS BANK UK,PLC (GBP)</div>
            </div>
            <div style="display: flex; justify-content: flex-end;align-items: center;">
                <div style="background-color: green;color: white; width: 80px;height: 30px;display: flex; justify-content: center;align-items: center;">
                    <div>Default</div>
                </div>
            </div>
        </div>
    </div>


    <!-- bank account detail end -->

    <!-- transfer payout start -->
    <div id="transpay">
        <div class="containertrans">
            <a class="nav-link" href="#scrollspyHeading1" style="text-decoration: none;color: black;">
                Transfers
            </a>
        </div>
        <div class="containertrans">
            <a class="nav-link" href="#scrollspyHeading2" style="text-decoration: none;color: black;">
                <div>Payouts</div>
            </a>
        </div>
    </div>
    <!-- transfer payout end -->
    <!-- content transfer start -->
    <div style="margin-bottom: 50%;">
        <div style="width: 90%;height:200px;margin:auto;overflow-y: scroll;">
            <div id="rendetprof11 scrollspyHeading1">
                <div id="renderprof1">
                    <div class="renderprof2">
                        <div id="teea1pic"></div>
                    </div>

                    <div>
                        <div class="bigfont" style="font-weight:bolder ;">Rixo, Dress,UK 6</div>
                        <div>27 Apr - 01 May</div>
                    </div>
                </div>
                <div class="renderprof2">
                    <div>
                        <div>$29.25</div>
                    </div>
                </div>
            </div>

            <!-- second -->
            <div id="rendetprof11 scrollspyHeading1">
                <div id="renderprof1">
                    <div class="renderprof2">
                        <div id="teea1pic"></div>
                    </div>

                    <div>
                        <div class="bigfont" style="font-weight:bolder ;">Rixo, Dress,UK 6</div>
                        <div>27 Apr - 01 May</div>
                    </div>
                </div>
                <div class="renderprof2">
                    <div>
                        <div>$29.25</div>
                    </div>
                </div>
            </div>


            <!-- third -->
            <div id="rendetprof11 scrollspyHeading1">
                <div id="renderprof1">
                    <div class="renderprof2">
                        <div id="teea1pic"></div>
                    </div>

                    <div>
                        <div class="bigfont" style="font-weight:bolder ;">Rixo, Dress,UK 6</div>
                        <div>27 Apr - 01 May</div>
                    </div>
                </div>
                <div class="renderprof2">
                    <div>
                        <div>$29.25</div>
                    </div>
                </div>
            </div>

            <!-- fourth -->
            <div id="rendetprof11 scrollspyHeading1">
                <div id="renderprof1">
                    <div class="renderprof2">
                        <div id="teea1pic"></div>
                    </div>

                    <div>
                        <div class="bigfont" style="font-weight:bolder ;">Rixo, Dress,UK 6</div>
                        <div>27 Apr - 01 May</div>
                    </div>
                </div>
                <div class="renderprof2">
                    <div>
                        <div>$29.25</div>
                    </div>
                </div>
            </div>
            <!-- link2 1 -->
            <div id="rendetprof11 scrollspyHeading2">
                <div id="renderprof1">
                    <div class="renderprof2">
                        <div id="teea1pic"></div>
                    </div>

                    <div>
                        <div class="bigfont" style="font-weight:bolder ;">Rixo, Dress,UK 6</div>
                        <div>27 Apr - 01 May</div>
                    </div>
                </div>
                <div class="renderprof2">
                    <div>
                        <div>$29.25</div>
                    </div>
                </div>
            </div>
            <!-- link2 2 -->
            <div id="rendetprof11 scrollspyHeading2">
                <div id="renderprof1">
                    <div class="renderprof2">
                        <div id="teea1pic"></div>
                    </div>

                    <div>
                        <div class="bigfont" style="font-weight:bolder ;">Rixo, Dress,UK 6</div>
                        <div>27 Apr - 01 May</div>
                    </div>
                </div>
                <div class="renderprof2">
                    <div>
                        <div>$29.25</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- content transfer end -->

    <!-- footer start -->
    <?php include 'footer.php' ?>
    <!-- footer end -->



    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

</body>

</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My products</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/7a4aae7e35.js" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/7a4aae7e35.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <!-- header start -->
    <div id="profile_header">
        <div class="iconprofileheader">
            <i class="fa-solid fa-arrow-left-long fa-2x"></i>
        </div>
        <div id="profile_heading">
            <div id="profheadrev">My Products</div>
        </div>
        <div class="iconprofileheader">
            <i class="fa-solid fa-circle-chevron-down fa-2x"></i>
        </div>
    </div>
    <!-- header end -->

    <div style="margin-bottom:50%">
        <div class="myproducts">
            <div class="prod1">
                <div class="imgprod1"></div>
                <div>
                    <div class="tory1">Tory Burchearrings</div>
                    <div class="tory2">117 views</div>
                    <div class="tory2">27 Favourites</div>
                    <div class="tory2">2 times rental out</div>
                </div>
            </div>


            <div class="prod1">
                <div class="imgprod2"></div>
                <div>
                    <div class="tory1">Tory Burchearrings</div>
                    <div class="tory2">117 views</div>
                    <div class="tory2">27 Favourites</div>
                    <div class="tory2">2 times rental out</div>
                </div>
            </div>
        </div>
        <div class="myproducts">
            <div class="prod1">
                <div class="imgprod3"></div>
                <div>
                    <div class="tory1">Tory Burchearrings</div>
                    <div class="tory2">117 views</div>
                    <div class="tory2">27 Favourites</div>
                    <div class="tory2">2 times rental out</div>
                </div>
            </div>


            <div class="prod1">
                <div class="imgprod4"></div>
                <div>
                    <div class="tory1">Tory Burchearrings</div>
                    <div class="tory2">117 views</div>
                    <div class="tory2">27 Favourites</div>
                    <div class="tory2">2 times rental out</div>
                </div>
            </div>
        </div>
        <div class="myproducts">
            <div class="prod1">
                <div class="imgprod5"></div>
                <div>
                    <div class="tory1">Tory Burchearrings</div>
                    <div class="tory2">117 views</div>
                    <div class="tory2">27 Favourites</div>
                    <div class="tory2">2 times rental out</div>
                </div>
            </div>
        </div>
    </div>

    <!-- footer start -->
    <?php include 'footer.php' ?>
    <!-- footer end -->


    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>


</body>

</html>
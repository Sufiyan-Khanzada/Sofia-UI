
    <!-- footerstart -->
    <div id="footer1">
        <div class="iconfooter"><a href="index.php" class="changes1"><i class="fa-solid fa-house "></i></a>
        </div>
        <div class="iconfooter"><a href="#" class="changes1"><i class="fa-solid fa-comments "></i></a></div>
        <div class="iconfooter"><a href="wardrobe.php" class="changes1"><i class="fa-solid fa-circle-plus "></i></a></div>
        <div class="iconfooter"><a href="notification.php" class="changes1"><i class="fa-solid fa-bell"></i></a></div>
        <div class="iconfooter"><a href="login.php" class="changes1"><i class="fa-solid fa-user"></i></a></div>
    </div>

    <!-- footer end -->
    <!--===============================================================================================-->

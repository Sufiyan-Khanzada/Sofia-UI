<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/7a4aae7e35.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <!-- header start -->
    <div id="profile_header">
        <div class="iconprofileheader">
            <i class="fa-solid fa-bars fa-2x"></i>
        </div>
        <div id="profile_heading">
            <div id="profhead">Profile</div>
        </div>
        <div class="iconprofileheader">
            <i class="fa-solid fa-gear fa-2x"></i>
        </div>
    </div>
    <!-- header end -->

    <!-- profile start -->

    <!-- <img src="profile.jpg" height="100%" width="100%" /> -->
    <div class="container mt-4 mb-4 p-3 d-flex justify-content-center">
        <div class="card p-4 cardbg">
            <div class=" image d-flex flex-column justify-content-center align-items-center"> <button class="btn1 btn-secondary imgprof"> </button> <span class="name mt-3">Sophia</span> <span class="idd">@glatzekatze</span>
                <div class="d-flex flex-row justify-content-center align-items-center gap-2">
                    <span class="idd1 st1"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span> </div>
                <span id="rat1">5.00/5</span>
            </div>
            <div class="d-flex flex-row justify-content-center align-items-center mt-1 inst1"><i class="fa-brands fa-instagram fa-2x"></i></div>
            <!-- <div class="d-flex flex-row justify-content-center align-items-center mt-3"> <span class="number">1069 <span class="follow">Followers</span></span>
                </div>
                <div class=" d-flex mt-2"> <button class="btn1 btn-dark">Edit Profile</button> </div>
                <div class="text mt-3"> <span>Eleanor Pena is a creator of minimalistic x bold graphics and digital artwork.<br><br> Artist/ Creative Director by Day #NFT minting@ with FND night. </span> </div>
                <div class="gap-3 mt-3 icons d-flex flex-row justify-content-center align-items-center">
                    <span><i class="fa fa-twitter"></i></span> <span><i class="fa fa-facebook-f"></i></span> <span><i class="fa fa-instagram"></i></span> <span><i class="fa fa-linkedin"></i></span> </div>
                <div class=" px-2 rounded mt-4 date "> <span class="join">Joined May,2021</span> </div> -->
        </div>
    </div>
    </div>
    <!-- profile end -->

    <!-- accordation start -->

    <div class="accordion accmar allinone" id="accordionExample">
        <div class="accordion-item shadcard">
            <h2 class="accordion-header" id="headingOne">
                <a href="favourite.php" class="ancacc"><button class="accordion-button collapsed txt8" type="button">
              Favourites
              
            </button></a>

            </h2>
        </div>

        <div class="accordion-item shadcard">
            <h2 class="accordion-header" id="headingTwo">
                <a href="reviews.php" class="ancacc"><button class="accordion-button collapsed txt8" type="button">
              Reviews
            </button></a>
            </h2>

        </div>

        <div class="accordion-item shadcard">
            <h2 class="accordion-header" id="headingThree">
                <a href="myproducts.php" class="ancacc"><button class="accordion-button collapsed txt8" type="button">
              My Products
            </button></a>
            </h2>

        </div>


        <div class="accordion-item shadcard">
            <h2 class="accordion-header" id="headingThree">
                <a href="#" class="ancacc"><button class="accordion-button collapsed txt8" type="button">
              Rented Products
            </button></a>
            </h2>

        </div>


        <div class="accordion-item shadcard">
            <h2 class="accordion-header" id="headingThree">
                <a href="#" class="ancacc"><button class="accordion-button collapsed txt8" type="button">
              Stats
            </button></a>
            </h2>

        </div>

        <div class="accordion-item shadcard">
            <h2 class="accordion-header" id="headingThree">
                <a href="lender_activity.php" class="ancacc"><button class="accordion-button collapsed txt8" type="button">
              Earning
            </button></a>
            </h2>

        </div>

    </div>

    <!-- accordation end -->
    <div class="gapfoot1">

    </div>

    <!-- footerstart -->
    <?php include 'footer.php' ?>
    

    <!-- footer end -->


    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>



</body>

</html>